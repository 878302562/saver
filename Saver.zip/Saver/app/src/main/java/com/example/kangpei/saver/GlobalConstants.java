package com.example.kangpei.saver;

import android.graphics.Color;

/**
 * Created by kangpei on 14/11/16.
 */

public class GlobalConstants {

    /**
     * 记账类型的数组
     * asdasdaasdaasdasdsadsda
     */
    public static final String[] types = new String[]{
            "Income", "Dinner", "Travel", "Snack",
            "Clothes", "Grocery", "Recreation", "Atheletics",
            "Shop", "Taxi", "Message", "Vocation",
            "Cosmetic", "E-Device", "Internet", "Express",
            "Animal", "Utilities", "Training", "Others"
    };

    public static final int[] colors = new int[]{
            Color.rgb(255, 136, 34), Color.rgb(234, 103, 68), Color.rgb(118, 136, 242),
            Color.rgb(247, 186, 91), Color.rgb(245, 113, 110), Color.rgb(102, 204, 238),
            Color.rgb(44, 216, 101), Color.rgb(255, 147, 54), Color.rgb(255, 183, 0),
            Color.rgb(255, 103, 185), Color.rgb(86, 178, 255), Color.rgb(102, 204, 238),
            Color.rgb(252, 88, 48), Color.rgb(72, 217, 207), Color.rgb(146, 141, 255),
            Color.rgb(110, 207, 239), Color.rgb(255, 105, 105), Color.rgb(255, 136, 34),
            Color.rgb(63, 171, 233), Color.rgb(88, 200, 77)
    };
    public static int BUDGET=0;

}
